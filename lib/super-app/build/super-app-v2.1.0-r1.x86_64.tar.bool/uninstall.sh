#!/bin/sh
echo "🗑️  Désinstallation de super-app..."

rm -f /usr/local/bin/super-app
rm -rf /usr/local/share/doc/super-app

echo "✅ super-app désinstallé"
