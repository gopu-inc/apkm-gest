#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "apkm.h"
#include "sandbox.h"

/**
 * APKM - Advanced Package Manager (Gopu.inc)
 * Main entry point
 */

void print_help() {
    printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
    printf("  APKM v0.1 - Advanced Package Manager for Alpine\n");
    printf("  Développé par gopu.inc\n");
    printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n");
    printf("USAGE:\n");
    printf("  apkm [COMMANDE] [OPTIONS]\n\n");
    printf("COMMANDES:\n");
    printf("  sync        Synchronise et affiche les paquets installés\n");
    printf("  install     Installe un paquet via sandbox isolée\n");
    printf("  audit       Analyse de sécurité (CVE) des binaires\n");
    printf("  rollback    Annule la dernière transaction système\n\n");
    printf("OPTIONS:\n");
    printf("  -j, --json  Sortie au format JSON (compatible jq)\n");
    printf("  -t, --toml  Sortie au format TOML\n");
    printf("  --help      Affiche ce message d'aide\n\n");
    printf("EXEMPLES:\n");
    printf("  apkm sync --json | jq\n");
    printf("  apkm sync -t > packages.toml\n\n");
}

int main(int argc, char *argv[]) {
    // Si aucun argument ou --help
    if (argc < 2 || strcmp(argv[1], "--help") == 0) {
        print_help();
        return 0;
    }

    char *command = argv[1];
    output_format_t selected_format = OUTPUT_TEXT;

    // Analyse des options (Flags)
    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "--json") == 0 || strcmp(argv[i], "-j") == 0 || strcmp(argv[i], "--jxi") == 0) {
            selected_format = OUTPUT_JSON;
        } else if (strcmp(argv[i], "--toml") == 0 || strcmp(argv[i], "-t") == 0) {
            selected_format = OUTPUT_TOML;
        }
    }

    // Routage des commandes
    if (strcmp(command, "sync") == 0) {
        sync_alpine_db(selected_format);
    } 
    else if (strcmp(command, "install") == 0) {
        printf("[APKM] Initialisation de la sandbox sécurisée...\n");
        // sandbox_init() sera appelé ici
    } 
    else if (strcmp(command, "audit") == 0) {
        printf("[APKM] Lancement de l'audit de sécurité...\n");
        // Logique pour scanner les CVE
    } 
    else if (strcmp(command, "rollback") == 0) {
        printf("[APKM] Restauration du snapshot système précédent...\n");
    } 
    else {
        fprintf(stderr, "[APKM] Erreur: Commande '%s' inconnue.\n", command);
        fprintf(stderr, "Utilisez 'apkm --help' pour voir la liste des commandes.\n");
        return 1;
    }

    return 0;
}

