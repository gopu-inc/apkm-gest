#include <stdio.h>
#include <string.h>
#include <curl/curl.h>

void push_package(const char *filepath) {
    printf("[APSM] Préparation du push vers github.com/gopu-inc/...\n");
    
    // Logique Git ou API GitHub pour uploader le .tar.bool
    // Exemple simplifié de commande système
    char cmd[512];
    snprintf(cmd, sizeof(cmd), "git add %s && git commit -m 'Release update' && git push", filepath);
    
    printf("[APSM] Exécution : %s\n", cmd);
    // system(cmd); 
}

int main(int argc, char *argv[]) {
    if (argc > 1 && strcmp(argv[1], "push") == 0) {
        push_package("build/package.tar.bool");
    } else {
        printf("Usage: apsm push --stat\n");
    }
    return 0;
}

